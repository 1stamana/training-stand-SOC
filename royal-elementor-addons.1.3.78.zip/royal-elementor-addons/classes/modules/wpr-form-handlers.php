<?php
require WPR_ADDONS_PATH . 'classes/modules/forms/wpr-recaptcha-handler.php';
require WPR_ADDONS_PATH . 'classes/modules/forms/wpr-actions-status.php';
require WPR_ADDONS_PATH . 'classes/modules/forms/wpr-send-email.php';
require WPR_ADDONS_PATH . 'classes/modules/forms/wpr-send-webhook.php';
require WPR_ADDONS_PATH . 'classes/modules/forms/wpr-file-upload.php';
require WPR_ADDONS_PATH . 'classes/modules/forms/wpr-submissions-cpt.php';
require WPR_ADDONS_PATH . 'classes/modules/forms/wpr-subscribe-mailchimp.php';